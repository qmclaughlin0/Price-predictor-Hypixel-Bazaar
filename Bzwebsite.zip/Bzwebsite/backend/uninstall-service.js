const Service = require('node-windows').Service;
const path = require('path');

// Create a new service object
const svc = new Service({
  name: 'Bazaar Tracker',
  script: path.join(__dirname, 'server.js')
});

// Listen for the "uninstall" event
svc.on('uninstall', function(){
  console.log('Service uninstalled successfully!');
});

// Uninstall the service
svc.uninstall();