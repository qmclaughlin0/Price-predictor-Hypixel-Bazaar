const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const https = require('https');
const http = require('http');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

// Initialize SQLite database
const db = new sqlite3.Database('./bazaar_data.db');

// Create table if it doesn't exist
db.serialize(() => {
    db.run(`CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id TEXT NOT NULL,
        buy_price REAL NOT NULL,
        sell_price REAL NOT NULL,
        buy_volume INTEGER NOT NULL,
        sell_volume INTEGER NOT NULL,
        timestamp INTEGER NOT NULL
    )`);
    
    db.run(`CREATE INDEX IF NOT EXISTS idx_product_timestamp ON price_history(product_id, timestamp)`);
});

// Fetch and store bazaar data
function fetchAndStoreBazaarData() {
    https.get('https://api.hypixel.net/skyblock/bazaar', (res) => {
        let data = '';
        
        res.on('data', (chunk) => {
            data += chunk;
        });
        
        res.on('end', () => {
            try {
                const jsonData = JSON.parse(data);
                
                if (jsonData.success) {
                    const timestamp = Date.now();
                    
                    for (const [productId, product] of Object.entries(jsonData.products)) {
                        db.run(`INSERT INTO price_history (product_id, buy_price, sell_price, buy_volume, sell_volume, timestamp) 
                                VALUES (?, ?, ?, ?, ?, ?)`,
                            [productId, 
                             product.quick_status.buyPrice,
                             product.quick_status.sellPrice,
                             product.quick_status.buyVolume,
                             product.quick_status.sellVolume,
                             timestamp]);
                    }
                    console.log(`Stored data for ${Object.keys(jsonData.products).length} products`);
                }
            } catch (error) {
                console.error('Error parsing bazaar data:', error);
            }
        });
    }).on('error', (error) => {
        console.error('Error fetching bazaar data:', error);
    });
}

// API Routes
app.get('/api/current', (req, res) => {
    https.get('https://api.hypixel.net/skyblock/bazaar', (response) => {
        let data = '';
        
        response.on('data', (chunk) => {
            data += chunk;
        });
        
        response.on('end', () => {
            try {
                const jsonData = JSON.parse(data);
                res.json(jsonData);
            } catch (error) {
                res.status(500).json({ error: 'Failed to parse data' });
            }
        });
    }).on('error', (error) => {
        res.status(500).json({ error: 'Failed to fetch current data' });
    });
});

app.get('/api/history/:productId', (req, res) => {
    const { productId } = req.params;
    const hours = req.query.hours || 24;
    const timeLimit = Date.now() - (hours * 60 * 60 * 1000);
    
    db.all(`SELECT * FROM price_history 
            WHERE product_id = ? AND timestamp > ? 
            ORDER BY timestamp ASC`,
        [productId, timeLimit],
        (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.json(rows);
            }
        });
});

app.get('/api/history', (req, res) => {
    const hours = req.query.hours || 6;
    const timeLimit = Date.now() - (hours * 60 * 60 * 1000);
    
    db.all(`SELECT * FROM price_history 
            WHERE timestamp > ? 
            ORDER BY product_id, timestamp ASC`,
        [timeLimit],
        (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                // Group by product_id
                const grouped = {};
                rows.forEach(row => {
                    if (!grouped[row.product_id]) {
                        grouped[row.product_id] = [];
                    }
                    grouped[row.product_id].push(row);
                });
                res.json(grouped);
            }
        });
});

// Start data collection
fetchAndStoreBazaarData();
setInterval(fetchAndStoreBazaarData, 5 * 60 * 1000); // Every 5 minutes

// Simple database viewer endpoint
app.get('/api/daily-volume', (req, res) => {
    const oneDayAgo = Date.now() - (24 * 60 * 60 * 1000);
    
    db.all(`SELECT product_id, 
                   SUM(buy_volume) as total_bought,
                   SUM(sell_volume) as total_sold
            FROM price_history 
            WHERE timestamp > ? 
            GROUP BY product_id`,
        [oneDayAgo],
        (err, rows) => {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                const dailyVolume = {};
                rows.forEach(row => {
                    dailyVolume[row.product_id] = {
                        bought: row.total_bought || 0,
                        sold: row.total_sold || 0
                    };
                });
                res.json(dailyVolume);
            }
        });
});

app.get('/api/stats', (req, res) => {
    db.get(`SELECT COUNT(*) as total_records FROM price_history`, (err, row) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            db.get(`SELECT COUNT(DISTINCT product_id) as unique_products FROM price_history`, (err2, row2) => {
                if (err2) {
                    res.status(500).json({ error: err2.message });
                } else {
                    res.json({
                        total_records: row.total_records,
                        unique_products: row2.unique_products
                    });
                }
            });
        }
    });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log(`Database stats: http://localhost:${PORT}/api/stats`);
});