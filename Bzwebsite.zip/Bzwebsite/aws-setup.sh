#!/bin/bash
# AWS EC2 Setup Script for Node.js Server

# Update system
sudo yum update -y

# Install Node.js 18
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Install PM2 for process management
sudo npm install -g pm2

# Create app directory
mkdir ~/bazaar-app
cd ~/bazaar-app

# Install git (if needed)
sudo yum install -y git

echo "Setup complete! Now upload your files."